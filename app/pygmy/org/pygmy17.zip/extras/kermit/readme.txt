These files related to Kermit are mostly unchanged from their original
release around 1997 other than a few corrections or notes about my
current email and web addresses and the software license.

My current email and web site addresses are

        frank@pygmy.utoh.org

        http://pygmy.utoh.org


-- 
Frank
